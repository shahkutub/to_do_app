import 'package:get/get.dart';
import 'package:listtodo_get/models/To_do.dart';

class ToDoController extends GetxController{
  var todos = List<ToDo>().obs;
}