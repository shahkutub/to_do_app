class ToDo{
  String text;
  bool done;

  ToDo({this.text,this.done = false});
}